﻿1 执行 new_data.sql、user.sql

2 后台登录用户名：abc、密码：123

3 在命令行输入set DEBUG=baidu_news & npm start

4 在浏览器中打开http://localhost:3000/