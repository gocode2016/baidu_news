var config = {
  host: 'localhost',
  user: 'root',
  password: '',
  database:'baidu_for_phone',
  port: 3306
}

module.exports = config;